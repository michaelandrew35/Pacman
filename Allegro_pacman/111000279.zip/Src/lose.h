#ifndef SCENE_LOSE_H
#define SCENE_LOSE_H

#include "game.h"
Scene scene_lose_create(void);
#endif
